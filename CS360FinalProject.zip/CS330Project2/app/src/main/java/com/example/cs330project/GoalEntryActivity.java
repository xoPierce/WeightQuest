package com.example.cs330project;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class GoalEntryActivity extends AppCompatActivity {
    // Declare a constant for the permission request
    private static final int PERMISSION_REQUEST_SEND_SMS = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goal_entry_screen);

        TextView cancelButton = findViewById(R.id.cancel_button);
        TextView saveButton = findViewById(R.id.save_button);
        EditText goalEditText = findViewById(R.id.goalEditText);

        // Initialize DatabaseHelper and SQLiteDatabase objects here
        GoalDatabase dbHelper = new GoalDatabase(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Handles logic for when the cancel button is pressed
        cancelButton.setOnClickListener(v -> {
            Intent intent = new Intent(GoalEntryActivity.this, WeightViewActivity.class);
            startActivity(intent);
        });

        // Handles logic for when the save button is pressed
        saveButton.setOnClickListener(v -> {
            String goal = goalEditText.getText().toString();

            // If there is no data in the goal field
            if (goal.isEmpty()) {
                Toast.makeText(this, "The goal field is empty", Toast.LENGTH_SHORT).show();
            }

            else {
                // Updates the goal in the database
                dbHelper.updateGoal(goal);

                // Starts the WeightViewActivity
                Intent intent = new Intent(GoalEntryActivity.this, WeightViewActivity.class);
                startActivity(intent);
            }
        });
    }
}

