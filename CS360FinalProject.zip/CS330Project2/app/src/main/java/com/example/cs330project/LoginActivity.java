package com.example.cs330project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        Button loginButton = findViewById(R.id.LogInButton);
        Button signUpButton = findViewById(R.id.SignUpButton);
        EditText usernameTextView = findViewById(R.id.UsernameEditText);
        EditText passwordTextView = findViewById(R.id.PasswordEditText);

        // Initialize DatabaseHelper and SQLiteDatabase objects here
        AccountDatabase dbHelper = new AccountDatabase(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        loginButton.setOnClickListener(v -> {
            String username = usernameTextView.getText().toString();
            String password = passwordTextView.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "The username or password field is empty", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isValidLogin = dbHelper.isLoginValid(username, password);
            if (isValidLogin) {
                Intent intent = new Intent(LoginActivity.this, WeightViewActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(this, "Invalid username and password combination", Toast.LENGTH_SHORT).show();
            }
        });

        signUpButton.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
            startActivity(intent);
        });
    }
}