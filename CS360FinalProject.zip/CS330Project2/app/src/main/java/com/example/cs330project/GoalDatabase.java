package com.example.cs330project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class GoalDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "goals.db";
    private static final int VERSION = 1;

    public GoalDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class GoalTable {
        private static final String TABLE = "goals";
        private static final String COL_ID = "_id";
        private static final String COL_GOAL = "goal";
    }

    // Method that inserts a new goal into the database
    public void updateGoal(String goal) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Check if a goal already exists in the database
        Cursor cursor = db.query(GoalTable.TABLE, null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            // Updates the existing goal
            ContentValues values = new ContentValues();
            values.put(GoalTable.COL_GOAL, goal);
            db.update(GoalTable.TABLE, values, null, null);
            cursor.close();
        }
        else {
            // Inserts a new goal
            ContentValues values = new ContentValues();
            values.put(GoalTable.COL_GOAL, goal);
            db.insert(GoalTable.TABLE, null, values);
        }
    }

    public String getGoal() {
        SQLiteDatabase db = this.getWritableDatabase();
        String goal = "";

        Cursor cursor = db.query(
                GoalTable.TABLE,
                new String[]{GoalTable.COL_GOAL},
                null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int goalColumnIndex = cursor.getColumnIndex(GoalTable.COL_GOAL);
            if (goalColumnIndex != -1) {
                goal = cursor.getString(goalColumnIndex);
            }
            cursor.close();
        }
        return goal;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + GoalTable.TABLE + " (" +
                GoalTable.COL_ID + " integer primary key autoincrement, " +
                GoalTable.COL_GOAL + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + GoalTable.TABLE);
        onCreate(db);
    }
}
