package com.example.cs330project;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
import android.widget.Toast;


public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up_screen);

        Button loginButton = findViewById(R.id.LogInButton);
        Button signUpButton = findViewById(R.id.SignUpButton);
        EditText usernameEditText = findViewById(R.id.UsernameEditText);
        EditText passwordEditText = findViewById(R.id.PasswordEditText);

        // Initialize DatabaseHelper and SQLiteDatabase objects here
        AccountDatabase dbHelper = new AccountDatabase(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();


        signUpButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "The username or password field is empty", Toast.LENGTH_SHORT).show();
                return;
            }

            if (dbHelper.isUsernameExists(username)) {
                Toast.makeText(this, "The username is already associated with an account", Toast.LENGTH_SHORT).show();
                return;
            }

            // Create a new account
            long result = dbHelper.createAccount(username, password);
            if (result != 0) {
                // Account was created successfully
                Intent intent = new Intent(SignUpActivity.this, WeightViewActivity.class);
                startActivity(intent);
            }

            else {
                Toast.makeText(this, "The user account could not be created", Toast.LENGTH_SHORT).show();
            }
       });


        loginButton.setOnClickListener(v -> {
            Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
            startActivity(intent);
        });
    }
}