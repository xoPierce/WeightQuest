package com.example.cs330project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Map;

public class EntryAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<WeightEntry> entries;

    public EntryAdapter(Context context, ArrayList<WeightEntry> entries) {
        this.context = context;
        this.entries = entries;
    }

    public void removeEntry(int position) {
        entries.remove(position);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return entries.size();
    }

    @Override
    public Object getItem(int position) {
        return entries.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.grid_item_layout, parent, false);
        }

        WeightEntry entry = entries.get(position);
        TextView weightTextView = convertView.findViewById(R.id.weightTextView);
        String weightDisplayText = entry.getWeight()  + " lbs";
        weightTextView.setText(weightDisplayText);

        TextView dateTextView = convertView.findViewById(R.id.dateTextView);
        dateTextView.setText(entry.getDate());

        return convertView;
    }
}
