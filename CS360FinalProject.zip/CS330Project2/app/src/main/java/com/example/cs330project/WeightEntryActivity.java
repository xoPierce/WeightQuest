package com.example.cs330project;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.Manifest;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.Objects;

public class WeightEntryActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 123; // You can choose any value


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_entry_screen);

        TextView cancelButton = findViewById(R.id.cancel_button);
        TextView saveButton = findViewById(R.id.save_button);
        EditText weightEditText = findViewById(R.id.weightEditText);

        // Initialize DatabaseHelper and SQLiteDatabase objects here
        WeightDatabase weightDatabase = new WeightDatabase(this);
        GoalDatabase goalDatabase = new GoalDatabase(this);
        SQLiteDatabase db = weightDatabase.getWritableDatabase();

        // Handles logic for when the cancel button is pressed
        cancelButton.setOnClickListener(v -> {
            Intent intent = new Intent(WeightEntryActivity.this, WeightViewActivity.class);
            startActivity(intent);
        });

        // Handles logic for when the save button is pressed
        saveButton.setOnClickListener(v -> {
            String weight = weightEditText.getText().toString();
            String goal = goalDatabase.getGoal();


            // If there is no data in the goal field
            if (weight.isEmpty()) {
                Toast.makeText(this, "The weight field is empty", Toast.LENGTH_SHORT).show();
            }
            // Checks to make sure the weight is above 0 lbs
            else {
                try {
                    double weightValue = Double.parseDouble(weight); // Convert string to double
                    int weightInt = (int) Math.round(weightValue); // Convert double to integer

                    if (weightInt <= 0) {
                        Toast.makeText(this, "The weight needs to be above 0 lbs", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    // Handle the case where weightStr cannot be parsed as a double
                    Toast.makeText(this, "Invalid weight format", Toast.LENGTH_SHORT).show();
                }
            }

            // If the goal does not exist
            if (Objects.equals(goal, "") || goal == null) {
                Toast.makeText(this, "NO GOAL", Toast.LENGTH_SHORT).show();
                // Adds a new weight in to the database
                weightDatabase.addWeight(weight);
                // Starts the WeightViewActivity
                Intent intent = new Intent(WeightEntryActivity.this, WeightViewActivity.class);
                startActivity(intent);
                return;
            }

            // Checks to see if the goal has been met
            if (Integer.parseInt(weight) <= Integer.parseInt(goalDatabase.getGoal())) {
                weightDatabase.addWeight(weight);
                // Check if the user has granted SMS permission
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED) {

                    // Request SMS permission
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},
                            SMS_PERMISSION_REQUEST_CODE);
                }

                else {
                    // Permission is already granted, send SMS here
                    sendCongratulationsSMS();
                    startWeightViewActivity();
                }
            }
            else {
                weightDatabase.addWeight(weight);
                startWeightViewActivity();
            }
        });
    }

    private void sendCongratulationsSMS() {
        String phoneNumber = "0001"; // Replace with the recipient's phone number
        String message = "Congratulations! You've reached your goal.";
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void startWeightViewActivity() {
        Intent intent = new Intent(WeightEntryActivity.this, WeightViewActivity.class);
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendCongratulationsSMS();
            }
            else {
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
            startWeightViewActivity();
        }
    }
}

