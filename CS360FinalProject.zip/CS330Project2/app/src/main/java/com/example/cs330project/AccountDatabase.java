package com.example.cs330project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AccountDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "accounts.db";
    private static final int VERSION = 1;

    public AccountDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class AccountTable {
        private static final String TABLE = "accounts";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    // Method that inserts a new account into the database
    public long createAccount(String username, String password) {
        ContentValues values = new ContentValues();
        values.put(AccountTable.COL_USERNAME, username);
        values.put(AccountTable.COL_PASSWORD, password);

        SQLiteDatabase db = this.getWritableDatabase();
        return db.insert(AccountTable.TABLE, null, values);
    }


    // Method that checks to see if a username already exists within the db
    public boolean isUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(AccountTable.TABLE,
                new String[]{AccountTable.COL_ID},
                AccountTable.COL_USERNAME + "=?",
                new String[]{username}, null, null, null, null);

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Method that checks if a username and pw combination exists in the db
    public boolean isLoginValid(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(AccountTable.TABLE,
                new String[]{AccountTable.COL_ID},
                AccountTable.COL_USERNAME + "=? AND " + AccountTable.COL_PASSWORD + "=?",
                new String[]{username, password}, null, null, null, null);

        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + AccountTable.TABLE + " (" +
                AccountTable.COL_ID + " integer primary key autoincrement, " +
                AccountTable.COL_USERNAME + " text, " +
                AccountTable.COL_PASSWORD + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + AccountTable.TABLE);
        onCreate(db);
    }
}

