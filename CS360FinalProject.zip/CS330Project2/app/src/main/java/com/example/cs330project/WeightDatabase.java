package com.example.cs330project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class WeightDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weights.db";
    private static final int VERSION = 1;

    public WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_WEIGHT = "weight";

        private static final String COL_DATE = "date";
    }

    // Method that inserts a new weight into the database
    public void addWeight(String weight) {
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT, weight);

        // Get current date and time
        long currentTimeMillis = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dateString = sdf.format(new Date(currentTimeMillis));
        values.put(WeightTable.COL_DATE, dateString);

        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(WeightTable.TABLE, null, values);
    }

    public ArrayList<WeightEntry> getAllEntries() {
        ArrayList<WeightEntry> entries = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(
            WeightTable.TABLE,
            new String[]{WeightTable.COL_ID, WeightTable.COL_WEIGHT, WeightTable.COL_DATE},
            null, null, null, null,
                WeightTable.COL_ID + " DESC"
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex(WeightTable.COL_ID);
                int weightIndex = cursor.getColumnIndex(WeightTable.COL_WEIGHT);
                int dateIndex = cursor.getColumnIndex(WeightTable.COL_DATE);

                int id = cursor.getInt(idIndex);
                String weight = cursor.getString(weightIndex);
                String date = cursor.getString(dateIndex);
                entries.add(new WeightEntry(id, weight, date));
            }
            cursor.close();
        }
        return entries;
    }


    public void updateWeight(int id, String newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT, newWeight);

        db.update(WeightTable.TABLE, values, WeightTable.COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    public void deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(WeightTable.TABLE, WeightTable.COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " integer primary key autoincrement, " +
                WeightTable.COL_WEIGHT + " text, " +
                WeightTable.COL_DATE + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        onCreate(db);
    }
}

