package com.example.cs330project;

public class WeightEntry {
    private int id;
    private String weight;
    private String date;

    public WeightEntry(int id, String weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }


}
