package com.example.cs330project;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.text.InputType;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import java.util.ArrayList;
import java.util.List;

public class WeightViewActivity extends AppCompatActivity {
    private ArrayList<WeightEntry> entries; // Declare the ArrayList globally
    GridView gridView;  // Declare the GridView globally
    EntryAdapter entryAdapter;  // Declare the Entry Adapter globally

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_view_screen);

        // Initialize DatabaseHelper and SQLiteDatabase objects here
        GoalDatabase goalDatabase = new GoalDatabase(this);
        WeightDatabase weightDatabase = new WeightDatabase(this);

        gridView = findViewById(R.id.gridView);

        // Fetch entries from the WeightDatabase
        entries = weightDatabase.getAllEntries();

        // Create and set the adapter for the GridView
        entryAdapter = new EntryAdapter(this, entries);

        // Set the adapter for the GridView
        gridView.setAdapter(entryAdapter);

        Button setGoalButton = findViewById(R.id.SetGoalButton);
        Button addWeightButton = findViewById(R.id.add_new_weight_button);

        // Called if there is no current goal
        if (goalDatabase.getGoal() == "") {
            setGoalButton.setText("SET GOAL");
        }

        else {
            String goalText = "GOAL: " + goalDatabase.getGoal() + " LBS";
            setGoalButton.setText(goalText);
        }

        // Called when one of the gridView elements have been pressed
        gridView.setOnItemClickListener((parent, view, position, id) -> {
            WeightEntry selectedEntry = entries.get(position);

            editOrDeleteDialog(selectedEntry, position);
        });

        // Called when the set goal button has been pressed
        setGoalButton.setOnClickListener(v -> {
            Intent intent = new Intent(WeightViewActivity.this, GoalEntryActivity.class);
            startActivity(intent);
        });

        // Called when the add new weight button has been pressed
        addWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(WeightViewActivity.this, WeightEntryActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (gridView == null) {
            gridView = findViewById(R.id.gridView);
        }

        // Refreshes and updates the entries ArrayList dynamically
        WeightDatabase weightDatabase = new WeightDatabase(this);
        entries.clear();
        entries.addAll(weightDatabase.getAllEntries());

        // Notifies the adapter that data has been changed
        if (gridView.getAdapter() != null) {
            ((BaseAdapter) gridView.getAdapter()).notifyDataSetChanged();
        }
    }

    private void editOrDeleteDialog(WeightEntry entry, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose an action").setItems(new CharSequence[]{"Edit", "Delete"}, (dialog, which) -> {
            if (which == 0) {
                AlertDialog.Builder editDialogBuilder = new AlertDialog.Builder(this);
                editDialogBuilder.setTitle("Edit Weight");

                // Create an EditText view to input the new weight
                EditText input = new EditText(this);
                input.setInputType(InputType.TYPE_CLASS_NUMBER);
                input.setText(entry.getWeight());
                editDialogBuilder.setView(input);

                // Set up the buttons
                editDialogBuilder.setPositiveButton("OK", (dialogInterface, i) -> {
                    String newWeight = input.getText().toString().trim();
                    if (!newWeight.isEmpty()) {
                        WeightDatabase weightDatabase = new WeightDatabase(this);
                        weightDatabase.updateWeight(entry.getId(), newWeight);

                        // Update the entry in the ArrayList
                        entry.setWeight(newWeight);
                        entryAdapter.notifyDataSetChanged();
                    }
                });
                editDialogBuilder.setNegativeButton("Cancel", ((dialogInterface, i) -> dialogInterface.cancel()));
                editDialogBuilder.create().show();
            } else if (which == 1) {
                WeightDatabase weightDatabase = new WeightDatabase(this);
                weightDatabase.deleteWeight(entry.getId());
                entryAdapter.removeEntry(position);
            }
        });
        builder.create().show();
    }
}
